package com.example.msgatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
